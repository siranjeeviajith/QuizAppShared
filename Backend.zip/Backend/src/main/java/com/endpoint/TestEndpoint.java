package com.endpoint;

import javax.ws.rs.Path;

@Path("/test")
public class TestEndpoint extends AbstractBaseApiEndpoint {

}
