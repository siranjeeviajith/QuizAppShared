package com.dao;

public interface TestDao {
}
