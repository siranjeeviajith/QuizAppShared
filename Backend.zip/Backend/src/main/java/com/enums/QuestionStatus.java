package com.enums;

public enum QuestionStatus {
    ACTIVE, DELETED
}
